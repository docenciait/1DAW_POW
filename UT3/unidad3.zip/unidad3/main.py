from helpers import *

name = 'Gafas VR'
price = 450.25
available = True
units = 20

def func1(x):
    return x * x
    


print(f'''
      Producto disponible {name} 
      El precio es {price} 
      Número de unidades {units}
      El resultado de multplicar 2 * 2: {func1(2)}      
            
      ''')

"""
Este es un comentario
multilínea
"""
