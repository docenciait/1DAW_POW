def sum(x,y):
    return x + y

def resta(x,y):
    return x - y